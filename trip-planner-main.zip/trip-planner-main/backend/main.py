import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from groq import Groq
from supabase import create_client, Client


# Load environment variables from backend/.env
load_dotenv(Path(__file__).with_name(".env"))


app = FastAPI(
    title="Trip Planner API",
    description="AI-powered personalized travel planning",
    version="1.1.0",
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Supabase configuration
def get_supabase_client() -> Client:
    url = os.getenv("SUPABASE_URL")
    key = os.getenv("SUPABASE_KEY")

    if not url or not key:
        raise HTTPException(
            status_code=500,
            detail="Supabase credentials are missing from backend/.env.",
        )

    try:
        return create_client(url, key)
    except Exception as exc:
        print(f"Supabase configuration error: {exc}")

        raise HTTPException(
            status_code=500,
            detail="Could not initialize the Supabase client.",
        )


class TripRequest(BaseModel):
    feature: str = Field(
        description="One of: itinerary, budget, packing"
    )
    destination: str = Field(min_length=1, max_length=100)
    days: int = Field(default=3, ge=1, le=30)
    budget: float = Field(default=10000, gt=0)
    travelers: int = Field(default=1, ge=1, le=100)
    travel_style: str = Field(default="Balanced", max_length=50)
    interests: str = Field(default="Sightseeing", max_length=500)


class SaveTripRequest(BaseModel):
    destination: str = Field(min_length=1, max_length=100)
    duration_days: int = Field(ge=1, le=30)
    travelers: int = Field(default=1, ge=1, le=100)
    budget: float = Field(gt=0)
    travel_style: str = Field(default="Balanced", max_length=50)
    interests: str = Field(default="Sightseeing", max_length=500)

    itinerary: str | None = None
    budget_breakdown: str | None = None
    packing_list: str | None = None


@app.get("/")
def home():
    return {
        "message": "Trip Planner API is running!",
        "status": "success",
    }


@app.get("/health")
def health_check():
    return {"status": "healthy"}


@app.post("/api/generate")
def generate_trip(request: TripRequest):
    api_key = os.getenv("GROQ_API_KEY")

    if not api_key:
        raise HTTPException(
            status_code=500,
            detail="GROQ_API_KEY is missing from the backend .env file.",
        )

    feature = request.feature.lower().strip()

    prompts = {
        "itinerary": (
            "Create a personalized day-by-day travel itinerary. "
            "For each day, include morning, afternoon, and evening "
            "activities, suggested attractions, food recommendations, "
            "and practical transportation advice. "
            "Avoid inventing exact opening hours or live prices."
        ),
        "budget": (
            "Create a practical travel budget breakdown. "
            "Include accommodation, food, local transport, activities, "
            "and miscellaneous expenses. Show estimated costs in INR, "
            "calculate the total, compare it with the user's budget, "
            "and suggest savings if necessary. Clearly state that "
            "prices are estimates, not live quotes."
        ),
        "packing": (
            "Create a personalized travel packing checklist. "
            "Organize it into clothing, toiletries, documents, "
            "electronics, medicines and essentials, and destination-"
            "specific items. Keep it practical and avoid unnecessary items."
        ),
    }

    if feature not in prompts:
        raise HTTPException(
            status_code=400,
            detail="Feature must be itinerary, budget, or packing.",
        )

    prompt = f"""
You are a helpful AI travel planning assistant.

Task:
{prompts[feature]}

Travel details:
- Destination: {request.destination}
- Duration: {request.days} days
- Total budget: INR {request.budget:,.2f}
- Travelers: {request.travelers}
- Travel style: {request.travel_style}
- Interests: {request.interests}

Make your response clear, useful, and well organized.
Use headings and bullet points.
For budgets, explain that all figures are estimates.
Do not claim to have checked live availability or prices.
"""

    try:
        client = Groq(api_key=api_key)

        response = client.chat.completions.create(
            model="openai/gpt-oss-20b",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are an experienced travel planning assistant. "
                        "Give practical, realistic, clearly structured advice."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0.5,
            max_completion_tokens=1800,
        )

        result = response.choices[0].message.content

        return {
            "success": True,
            "feature": feature,
            "destination": request.destination,
            "result": result or "No response was generated.",
        }

    except Exception as exc:
        print(f"Groq API error: {exc}")

        raise HTTPException(
            status_code=502,
            detail=(
                "AI generation failed. Check your API key, model availability, "
                "internet connection, and Groq API limits."
            ),
        )


@app.post("/api/trips")
def save_trip(trip: SaveTripRequest):
    supabase = get_supabase_client()

    trip_data = trip.model_dump()

    try:
        response = (
            supabase.table("planner_trips")
            .insert(trip_data)
            .execute()
        )

        saved_trips = response.data or []

        if not saved_trips:
            raise HTTPException(
                status_code=500,
                detail="The trip was not returned after saving.",
            )

        return {
            "success": True,
            "message": "Trip saved successfully.",
            "trip": saved_trips[0],
        }

    except HTTPException:
        raise

    except Exception as exc:
        print(f"Supabase save error: {exc}")

        raise HTTPException(
            status_code=500,
            detail=(
                "Could not save the trip. Check Supabase credentials, "
                "table columns, and database permissions."
            ),
        )


@app.get("/api/trips")
def get_saved_trips():
    supabase = get_supabase_client()

    try:
        response = (
            supabase.table("planner_trips")
            .select("*")
            .order("created_at", desc=True)
            .limit(50)
            .execute()
        )

        return {
            "success": True,
            "count": len(response.data or []),
            "trips": response.data or [],
        }

    except Exception as exc:
        print(f"Supabase retrieval error: {exc}")

        raise HTTPException(
            status_code=500,
            detail=(
                "Could not retrieve trips. Check Supabase credentials, "
                "table columns, and database permissions."
            ),
        )