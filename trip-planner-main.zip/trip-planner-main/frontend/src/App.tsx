import { useState } from "react";
import ReactMarkdown from "react-markdown";
import "./App.css";

type Feature = "itinerary" | "budget" | "packing";

interface TripForm {
  destination: string;
  days: number;
  budget: number;
  travelers: number;
  travel_style: string;
  interests: string;
}

interface ApiResponse {
  success: boolean;
  feature: Feature;
  destination: string;
  result: string;
}

interface TripResults {
  itinerary: string;
  budget: string;
  packing: string;
}

interface SavedTrip {
  id?: number | string;
  destination: string;
  duration_days: number;
  travelers: number;
  budget: number;
  travel_style: string;
  interests: string;
  itinerary?: string | null;
  budget_breakdown?: string | null;
  packing_list?: string | null;
  created_at?: string;
}

const API_URL = import.meta.env.VITE_API_URL || "";

const EMPTY_RESULTS: TripResults = {
  itinerary: "",
  budget: "",
  packing: "",
};

function App() {
  const [feature, setFeature] = useState<Feature>("itinerary");

  const [form, setForm] = useState<TripForm>({
    destination: "",
    days: 3,
    budget: 10000,
    travelers: 1,
    travel_style: "Balanced",
    interests: "Sightseeing, local food, nature",
  });

  const [results, setResults] = useState<TripResults>({
    ...EMPTY_RESULTS,
  });

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loadingTrips, setLoadingTrips] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [savedTrips, setSavedTrips] = useState<SavedTrip[]>([]);
  const [showSavedTrips, setShowSavedTrips] = useState(false);

  const result = results[feature];

  function updateField(
    field: keyof TripForm,
    value: string | number
  ) {
    setForm((previous) => ({
      ...previous,
      [field]: value,
    }));
  }

  async function generateTrip(
    event: React.FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();

    setLoading(true);
    setError("");
    setMessage("");

    try {
      const response = await fetch(`${API_URL}/api/generate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          feature,
          ...form,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.detail || "Unable to generate your travel plan."
        );
      }

      const generated = data as ApiResponse;

      setResults((previous) => ({
        ...previous,
        [generated.feature]: generated.result,
      }));
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Something went wrong. Please try again."
      );
    } finally {
      setLoading(false);
    }
  }

  async function saveCompleteTrip() {
    if (!form.destination.trim()) {
      setError("Enter a destination before saving your trip.");
      return;
    }

    if (
      !results.itinerary &&
      !results.budget &&
      !results.packing
    ) {
      setError("Generate at least one result before saving your trip.");
      return;
    }

    setSaving(true);
    setError("");
    setMessage("");

    try {
      const response = await fetch(`${API_URL}/api/trips`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          destination: form.destination,
          duration_days: form.days,
          travelers: form.travelers,
          budget: form.budget,
          travel_style: form.travel_style,
          interests: form.interests,
          itinerary: results.itinerary || null,
          budget_breakdown: results.budget || null,
          packing_list: results.packing || null,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Unable to save your trip.");
      }

      setMessage("Your trip was saved successfully!");

      if (showSavedTrips) {
        await loadSavedTrips();
      }
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Unable to save your trip."
      );
    } finally {
      setSaving(false);
    }
  }

  async function loadSavedTrips() {
    setLoadingTrips(true);
    setError("");
    setMessage("");

    try {
      const response = await fetch(`${API_URL}/api/trips`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Unable to load saved trips.");
      }

      setSavedTrips(data.trips || []);
      setShowSavedTrips(true);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Unable to load saved trips."
      );
    } finally {
      setLoadingTrips(false);
    }
  }

  function openSavedTrip(trip: SavedTrip) {
    setForm({
      destination: trip.destination,
      days: trip.duration_days,
      budget: Number(trip.budget),
      travelers: trip.travelers,
      travel_style: trip.travel_style,
      interests: trip.interests,
    });

    setResults({
      itinerary: trip.itinerary || "",
      budget: trip.budget_breakdown || "",
      packing: trip.packing_list || "",
    });

    setFeature(
      trip.itinerary
        ? "itinerary"
        : trip.budget_breakdown
          ? "budget"
          : "packing"
    );

    setShowSavedTrips(false);
    setError("");
    setMessage(`Loaded your trip to ${trip.destination}.`);

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  const featureDetails = {
    itinerary: {
      title: "Your next adventure starts here.",
      description:
        "Create a personalized day-by-day travel itinerary with AI.",
      button: "Generate My Itinerary",
      icon: "🗺️",
    },
    budget: {
      title: "Travel smarter, spend better.",
      description:
        "Estimate your travel expenses and discover ways to save money.",
      button: "Calculate My Budget",
      icon: "💰",
    },
    packing: {
      title: "Pack light. Travel right.",
      description:
        "Generate a personalized packing checklist for your destination.",
      button: "Create My Packing List",
      icon: "🎒",
    },
  };

  const details = featureDetails[feature];

  return (
    <div className="app-shell">
      <header className="navbar">
        <a className="brand" href="/">
          <span className="brand-icon">✈</span>
          <span>
            Trip<span className="brand-accent">Planner</span>
          </span>
        </a>

        <span className="nav-label">
          YOUR PERSONAL AI TRAVEL ASSISTANT
        </span>

        <div className="status-badge">
          <span className="status-dot" />
          AI Travel Planner
        </div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-pill">
            <span>✦</span> YOUR JOURNEY, REIMAGINED WITH AI
          </div>

          <h1>
            Explore more.
            <br />
            <span>Plan less.</span>
          </h1>

          <p>
            Tell us what you love, where you want to go, and your
            budget. We'll help you plan a more memorable trip.
          </p>
        </section>

        <div className="saved-trips-toolbar">
          <button
            type="button"
            className="copy-button"
            onClick={loadSavedTrips}
            disabled={loadingTrips}
          >
            {loadingTrips ? "Loading..." : "My Trips"}
          </button>
        </div>

        {showSavedTrips && (
          <section className="saved-trips-section">
            <div className="card-heading">
              <div>
                <span className="eyebrow">YOUR COLLECTION</span>
                <h2>My Saved Trips</h2>
              </div>

              <button
                type="button"
                className="copy-button"
                onClick={() => setShowSavedTrips(false)}
              >
                Close
              </button>
            </div>

            {savedTrips.length === 0 ? (
              <p>You haven't saved any trips yet.</p>
            ) : (
              <div className="saved-trips-list">
                {savedTrips.map((trip, index) => (
                  <article
                    className="saved-trip-item"
                    key={trip.id ?? `${trip.destination}-${index}`}
                  >
                    <div>
                      <h3>📍 {trip.destination}</h3>
                      <p>
                        {trip.duration_days} days · {trip.travelers}{" "}
                        traveler{trip.travelers === 1 ? "" : "s"} · ₹
                        {Number(trip.budget).toLocaleString("en-IN")}
                      </p>
                      <small>
                        {trip.created_at
                          ? new Date(trip.created_at).toLocaleDateString()
                          : "Saved trip"}
                      </small>
                    </div>

                    <button
                      type="button"
                      className="copy-button"
                      onClick={() => openSavedTrip(trip)}
                    >
                      Open Trip
                    </button>
                  </article>
                ))}
              </div>
            )}
          </section>
        )}

        <section className="planner-layout">
          <div className="form-card">
            <div className="card-heading">
              <div>
                <span className="eyebrow">LET'S PLAN</span>
                <h2>Design your journey</h2>
                <p>
                  Customize your trip to match your travel style.
                </p>
              </div>
              <div className="heading-icon">✈️</div>
            </div>

            <div
              className="feature-tabs"
              aria-label="Travel planning feature"
            >
              <button
                type="button"
                className={
                  feature === "itinerary"
                    ? "feature-tab active"
                    : "feature-tab"
                }
                onClick={() => {
                  setFeature("itinerary");
                  setError("");
                  setMessage("");
                }}
              >
                <span>🗺️</span> Itinerary
              </button>

              <button
                type="button"
                className={
                  feature === "budget"
                    ? "feature-tab active"
                    : "feature-tab"
                }
                onClick={() => {
                  setFeature("budget");
                  setError("");
                  setMessage("");
                }}
              >
                <span>💰</span> Budget
              </button>

              <button
                type="button"
                className={
                  feature === "packing"
                    ? "feature-tab active"
                    : "feature-tab"
                }
                onClick={() => {
                  setFeature("packing");
                  setError("");
                  setMessage("");
                }}
              >
                <span>🎒</span> Packing
              </button>
            </div>

            <form onSubmit={generateTrip}>
              <div className="field-group">
                <label htmlFor="destination">
                  Where do you want to go?
                </label>
                <input
                  id="destination"
                  type="text"
                  placeholder="e.g. Goa, Manali, Jaipur..."
                  value={form.destination}
                  onChange={(event) =>
                    updateField("destination", event.target.value)
                  }
                  maxLength={100}
                  required
                />
              </div>

              <div className="form-grid">
                <div className="field-group">
                  <label htmlFor="days">Duration (days)</label>
                  <input
                    id="days"
                    type="number"
                    min="1"
                    max="30"
                    value={form.days}
                    onChange={(event) =>
                      updateField("days", Number(event.target.value))
                    }
                    required
                  />
                </div>

                <div className="field-group">
                  <label htmlFor="travelers">Travelers</label>
                  <input
                    id="travelers"
                    type="number"
                    min="1"
                    max="100"
                    value={form.travelers}
                    onChange={(event) =>
                      updateField(
                        "travelers",
                        Number(event.target.value)
                      )
                    }
                    required
                  />
                </div>
              </div>

              <div className="field-group">
                <label htmlFor="budget">Total budget (₹)</label>
                <div className="input-with-prefix">
                  <span>₹</span>
                  <input
                    id="budget"
                    type="number"
                    min="1"
                    value={form.budget}
                    onChange={(event) =>
                      updateField("budget", Number(event.target.value))
                    }
                    required
                  />
                </div>
              </div>

              <div className="field-group">
                <label htmlFor="travel_style">Travel style</label>
                <select
                  id="travel_style"
                  value={form.travel_style}
                  onChange={(event) =>
                    updateField("travel_style", event.target.value)
                  }
                >
                  <option>Budget</option>
                  <option>Balanced</option>
                  <option>Luxury</option>
                  <option>Adventure</option>
                  <option>Relaxation</option>
                  <option>Family</option>
                  <option>Romantic</option>
                </select>
              </div>

              <div className="field-group">
                <label htmlFor="interests">Your interests</label>
                <textarea
                  id="interests"
                  rows={3}
                  maxLength={500}
                  placeholder="Beaches, food, nature, shopping..."
                  value={form.interests}
                  onChange={(event) =>
                    updateField("interests", event.target.value)
                  }
                />
              </div>

              <button
                className="generate-button"
                type="submit"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="spinner" />
                    Creating your plan...
                  </>
                ) : (
                  <>
                    {details.icon} {details.button} <span>→</span>
                  </>
                )}
              </button>

              <p className="privacy-note">
                ✨ Personalized with generative AI
              </p>
            </form>
          </div>

          <div className="results-panel">
            {!result && !loading && !error && !message && (
              <div className="empty-state">
                <div className="empty-illustration">
                  {details.icon}
                </div>
                <span className="eyebrow">MADE FOR YOU</span>
                <h2>{details.title}</h2>
                <p>{details.description}</p>

                <div className="benefit-list">
                  <div>
                    <span>✓</span>
                    Personalized recommendations
                  </div>
                  <div>
                    <span>✓</span>
                    Designed around your budget
                  </div>
                  <div>
                    <span>✓</span>
                    Tailored to your preferences
                  </div>
                </div>

                <div className="results-tip">
                  <span>💡</span>
                  <p>
                    <strong>Travel tip</strong>
                    <br />
                    Enter your destination and preferences, then let AI
                    do the planning.
                  </p>
                </div>
              </div>
            )}

            {loading && (
              <div className="loading-state">
                <div className="loading-icon">{details.icon}</div>
                <h2>Creating something wonderful...</h2>
                <p>
                  Our AI is preparing your personalized{" "}
                  {feature === "itinerary"
                    ? "itinerary"
                    : feature === "budget"
                      ? "budget breakdown"
                      : "packing checklist"}
                  .
                </p>
                <div className="loading-bar">
                  <span />
                </div>
                <small>This may take a few seconds.</small>
              </div>
            )}

            {error && (
              <div className="error-state">
                <span className="error-icon">!</span>
                <h2>Something needs attention</h2>
                <p>{error}</p>
                <button
                  type="button"
                  className="retry-button"
                  onClick={() => setError("")}
                >
                  Dismiss
                </button>
              </div>
            )}

            {message && !error && (
              <p className="privacy-note">{message}</p>
            )}

            {result && !loading && (
              <div className="result-card">
                <div className="result-heading">
                  <div>
                    <span className="eyebrow">
                      YOUR PERSONALIZED PLAN
                    </span>
                    <h2>
                      {details.icon} {form.destination}
                    </h2>
                    <p>
                      {form.days} days · {form.travelers} traveler
                      {form.travelers === 1 ? "" : "s"} ·{" "}
                      {form.travel_style}
                    </p>
                  </div>

                  <button
                    type="button"
                    className="copy-button"
                    onClick={async () => {
                      try {
                        await navigator.clipboard.writeText(result);
                        setMessage("Result copied to clipboard.");
                        setError("");
                      } catch {
                        setError(
                          "Unable to copy automatically. Please select and copy the result."
                        );
                      }
                    }}
                    title="Copy your plan"
                  >
                    Copy
                  </button>
                </div>

                <div className="result-content">
                  <ReactMarkdown
                    components={{
                      h1: ({ children }) => <h1>{children}</h1>,
                      h2: ({ children }) => <h2>{children}</h2>,
                      h3: ({ children }) => <h3>{children}</h3>,
                      p: ({ children }) => <p>{children}</p>,
                      ul: ({ children }) => <ul>{children}</ul>,
                      ol: ({ children }) => <ol>{children}</ol>,
                      li: ({ children }) => <li>{children}</li>,
                      strong: ({ children }) => (
                        <strong>{children}</strong>
                      ),
                      table: ({ children }) => (
                        <div className="markdown-table-wrapper">
                          <table>{children}</table>
                        </div>
                      ),
                    }}
                  >
                    {result.replace(/<br\s*\/?>/gi, "\n")}
                  </ReactMarkdown>
                </div>

                <div className="result-footer">
                  <span>✦ Generated with AI</span>
                  <button
                    type="button"
                    onClick={() => {
                      setResults((previous) => ({
                        ...previous,
                        [feature]: "",
                      }));
                      setError("");
                      setMessage("");
                    }}
                  >
                    Clear this result ↗
                  </button>
                </div>
              </div>
            )}

            {(results.itinerary ||
              results.budget ||
              results.packing) && (
              <div className="save-trip-card">
                <h3>💾 Save your complete trip</h3>
                <p>
                  Save your generated itinerary, budget, and packing
                  checklist together.
                </p>

                <div className="result-status-list">
                  <span>
                    {results.itinerary ? "✓" : "○"} Itinerary
                  </span>
                  <span>
                    {results.budget ? "✓" : "○"} Budget
                  </span>
                  <span>
                    {results.packing ? "✓" : "○"} Packing list
                  </span>
                </div>

                <button
                  type="button"
                  className="generate-button"
                  onClick={saveCompleteTrip}
                  disabled={saving || loading}
                >
                  {saving ? "Saving trip..." : "Save Complete Trip"}
                </button>
              </div>
            )}
          </div>
        </section>

        <section className="feature-highlights">
          <div>
            <span className="highlight-icon">🗺️</span>
            <h3>Personalized itineraries</h3>
            <p>Day-by-day suggestions based on your interests.</p>
          </div>
          <div>
            <span className="highlight-icon">💰</span>
            <h3>Smarter budgeting</h3>
            <p>Understand estimated costs before you travel.</p>
          </div>
          <div>
            <span className="highlight-icon">🎒</span>
            <h3>Stress-free packing</h3>
            <p>Know what to bring for your destination.</p>
          </div>
        </section>
      </main>

      <footer className="footer">
        <a className="brand footer-brand" href="/">
          <span className="brand-icon">✈</span>
          <span>
            Trip<span className="brand-accent">Planner</span>
          </span>
        </a>
        <p>Made for curious minds and unforgettable journeys.</p>
        <span>© 2026 Trip Planner</span>
      </footer>
    </div>
  );
}

export default App;